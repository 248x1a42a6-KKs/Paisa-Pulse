import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/categories.dart';
import '../models/expense.dart';
import '../services/expense_provider.dart';

class AddPage extends StatefulWidget {
  const AddPage({super.key});

  @override
  State<AddPage> createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {
  final formKey = GlobalKey<FormState>();
  TextEditingController amount = TextEditingController();
  TextEditingController note = TextEditingController();

  String? category;
  DateTime date = DateTime.now();
  bool saving = false;

  @override
  void dispose() {
    amount.dispose();
    note.dispose();
    super.dispose();
  }

  void save() async {
    if (saving) return;
    if (!formKey.currentState!.validate()) return;

    saving = true;
    ExpenseProvider provider = context.read<ExpenseProvider>();

    await provider.addExpense(
      Expense(
        note.text.trim(),
        category!,
        double.parse(amount.text.trim()),
        date,
      ),
    );

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Expense')),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            children: [
              TextFormField(
                controller: amount,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Amount',
                  prefixText: '₹ ',
                ),
                validator: (value) {
                  double? a = double.tryParse((value ?? '').trim());
                  if (a == null) return 'Enter a number';
                  if (a <= 0) return 'Must be more than 0';
                  if (a > 10000000) return 'Amount is too large';
                  return null;
                },
              ),

              SizedBox(height: 16),

              DropdownButtonFormField<String>(
                initialValue: category,
                decoration: InputDecoration(labelText: 'Category'),
                items: categories.map((c) {
                  return DropdownMenuItem(
                    value: c,
                    child: Text(c),
                  );
                }).toList(),
                onChanged: (value) {
                  category = value;
                },
                validator: (value) {
                  if (value == null) return 'Choose a category';
                  return null;
                },
              ),

              SizedBox(height: 16),

              TextFormField(
                controller: note,
                maxLines: 2,
                decoration: InputDecoration(labelText: 'Note'),
                validator: (value) {
                  String t = (value ?? '').trim();
                  if (t.length < 3) return 'Write at least 3 letters';
                  if (t.length > 80) return 'Too long (max 80)';
                  return null;
                },
              ),

              SizedBox(height: 16),

              ListTile(
                title: Text(
                  'Date: ${date.day}/${date.month}/${date.year}',
                ),
                trailing: Icon(Icons.calendar_month),
                onTap: () async {
                  DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: date,
                    firstDate: DateTime(2020),
                    lastDate: DateTime.now(),
                  );

                  if (picked != null) {
                    setState(() {
                      date = picked;
                    });
                  }
                },
              ),

              SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: save,
                  child: Text('Save Expense'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
