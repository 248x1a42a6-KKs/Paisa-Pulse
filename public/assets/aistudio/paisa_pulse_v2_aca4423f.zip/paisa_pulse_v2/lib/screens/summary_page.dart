import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/categories.dart';
import '../services/expense_provider.dart';

class SummaryPage extends StatelessWidget {
  const SummaryPage({super.key});

  @override
  Widget build(BuildContext context) {
    ExpenseProvider provider = context.watch<ExpenseProvider>();
    double total = provider.total;

    return Scaffold(
      appBar: AppBar(title: Text('Summary')),

      body: provider.expenses.isEmpty
          ? Center(child: Text('No expenses available'))
          : ListView(
              padding: EdgeInsets.all(16),
              children: [
                Text(
                  'Total: ₹${total.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: 20),

                for (String c in categories)
                  categoryRow(c, provider.totalFor(c), total),
              ],
            ),
    );
  }

  Widget categoryRow(String category, double amount, double total) {
    if (amount == 0) {
      return SizedBox();
    }

    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$category: ₹${amount.toStringAsFixed(2)}',
          ),
          SizedBox(height: 6),
          LinearProgressIndicator(
            value: amount / total,
          ),
        ],
      ),
    );
  }
}
