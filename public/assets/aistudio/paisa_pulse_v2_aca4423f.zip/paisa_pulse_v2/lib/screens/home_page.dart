import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/expense_provider.dart';
import '../services/load_status.dart';
import '../widgets/budget_card.dart';
import '../widgets/budget_dialog.dart';
import '../widgets/expense_card.dart';
import 'add_page.dart';
import 'detail_page.dart';
import 'summary_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void setBudget(BuildContext context) async {
    ExpenseProvider provider = context.read<ExpenseProvider>();

    double? value = await showDialog<double>(
      context: context,
      builder: (context) => BudgetDialog(current: provider.budget),
    );

    if (value != null) {
      provider.setBudget(value);
    }
  }

  void showSummary(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SummaryPage(),
      ),
    );
  }

  void showAddPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddPage(),
      ),
    );
  }

  Widget buildBody(BuildContext context, ExpenseProvider provider) {
    ColorScheme colors = Theme.of(context).colorScheme;

    // state 1: loading
    if (provider.status == LoadStatus.loading) {
      return Center(child: CircularProgressIndicator());
    }

    // state 2: error
    if (provider.status == LoadStatus.error) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Could not load your expenses'),
            SizedBox(height: 12),
            FilledButton(
              onPressed: provider.loadData,
              child: Text('Retry'),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Monthly spending
        Card(
          color: colors.primary,
          margin: EdgeInsets.all(12),
          child: ListTile(
            title: Text(
              'Spent this month',
              style: TextStyle(color: colors.onPrimary),
            ),
            subtitle: Text(
              '₹${provider.monthTotal.toStringAsFixed(2)}',
              style: TextStyle(
                color: colors.onPrimary,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        // Budget card
        BudgetCard(
          spent: provider.monthTotal,
          budget: provider.budget,
          onTap: () => setBudget(context),
        ),

        SizedBox(height: 12),

        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Recent Expenses',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        // state 3 and 4: empty or the list
        Expanded(
          child: provider.expenses.isEmpty
              ? Center(child: Text('No expenses yet'))
              : ListView.builder(
                  padding: EdgeInsets.only(bottom: 80),
                  itemCount: provider.expenses.length,
                  itemBuilder: (context, index) {
                    var e = provider.expenses[index];

                    return ExpenseCard(
                      expense: e,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailPage(expenseId: e.id),
                          ),
                        );
                      },
                    );
                  },
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    ExpenseProvider provider = context.watch<ExpenseProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Paisa Pulse'),
        actions: [
          IconButton(
            icon: Icon(Icons.bar_chart),
            onPressed: () => showSummary(context),
          ),
        ],
      ),
      body: buildBody(context, provider),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showAddPage(context),
        child: Icon(Icons.add),
      ),
    );
  }
}
