import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/expense.dart';
import '../services/expense_provider.dart';

class DetailPage extends StatelessWidget {
  final String expenseId;

  const DetailPage({super.key, required this.expenseId});

  void askDelete(BuildContext context) async {
    ExpenseProvider provider = context.read<ExpenseProvider>();

    bool? sure = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete expense?'),
        content: Text('This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Delete'),
          ),
        ],
      ),
    );

    if (sure == true) {
      await provider.deleteExpense(expenseId);
      if (context.mounted) {
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    ExpenseProvider provider = context.watch<ExpenseProvider>();

    Expense? e;
    for (var item in provider.expenses) {
      if (item.id == expenseId) {
        e = item;
      }
    }

    if (e == null) {
      return Scaffold(appBar: AppBar());
    }

    double share = provider.total == 0 ? 0 : e.amount / provider.total * 100;

    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Details'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => askDelete(context),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          Text(
            '₹${e.amount.toStringAsFixed(2)}',
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Text('Category: ${e.category}'),
          SizedBox(height: 10),
          Text('Date: ${e.dateText}'),
          SizedBox(height: 10),
          Text('Share of all spending: ${share.toStringAsFixed(1)}%'),
          SizedBox(height: 10),
          Text('Note: ${e.note}'),
        ],
      ),
    );
  }
}
