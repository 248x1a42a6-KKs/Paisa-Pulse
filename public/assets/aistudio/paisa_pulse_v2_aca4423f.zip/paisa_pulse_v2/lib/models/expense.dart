class Expense {
  String id;
  String note, category;
  double amount;
  DateTime date;

  Expense(this.note, this.category, this.amount, this.date, {String? id})
      : id = id ?? DateTime.now().microsecondsSinceEpoch.toString();

  String get dateText => '${date.day}/${date.month}/${date.year}';

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'note': note,
      'category': category,
      'amount': amount,
      'date': date.toIso8601String(),
    };
  }

  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      json['note'] as String,
      json['category'] as String,
      (json['amount'] as num).toDouble(),
      DateTime.parse(json['date'] as String),
      id: json['id'] as String,
    );
  }
}
