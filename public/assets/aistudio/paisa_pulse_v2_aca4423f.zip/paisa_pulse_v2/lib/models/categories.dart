List<String> categories = [
  'Food', 'Travel', 'Study',
  'Bills', 'Fun', 'Health', 'Other'
];
