import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/expense.dart';

class StorageService {
  Future<List<Expense>> readExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    String? text = prefs.getString('expenses');
    if (text == null) return [];

    List<dynamic> list = jsonDecode(text);
    return list.map((item) => Expense.fromJson(item)).toList();
  }

  Future<void> saveExpenses(List<Expense> expenses) async {
    final prefs = await SharedPreferences.getInstance();
    String text = jsonEncode(expenses.map((e) => e.toJson()).toList());
    await prefs.setString('expenses', text);
  }

  Future<double> readBudget() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble('budget') ?? 0;
  }

  Future<void> saveBudget(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('budget', value);
  }
}
