import 'package:flutter/foundation.dart';

import '../models/expense.dart';
import 'load_status.dart';
import 'storage_service.dart';

class ExpenseProvider extends ChangeNotifier {
  final StorageService _storage = StorageService();

  List<Expense> expenses = [];
  double budget = 0;
  LoadStatus status = LoadStatus.loading;

  Future<void> loadData() async {
    status = LoadStatus.loading;
    notifyListeners();

    try {
      expenses = await _storage.readExpenses();
      budget = await _storage.readBudget();
      expenses.sort((a, b) => b.date.compareTo(a.date));
      status = LoadStatus.ready;
    } catch (e) {
      status = LoadStatus.error;
    }
    notifyListeners();
  }

  double get total {
    double sum = 0;
    for (var e in expenses) {
      sum += e.amount;
    }
    return sum;
  }

  double get monthTotal {
    double sum = 0;
    DateTime now = DateTime.now();

    for (var e in expenses) {
      if (e.date.month == now.month && e.date.year == now.year) {
        sum += e.amount;
      }
    }
    return sum;
  }

  double totalFor(String category) {
    double sum = 0;
    for (var e in expenses) {
      if (e.category == category) {
        sum += e.amount;
      }
    }
    return sum;
  }

  Future<void> addExpense(Expense e) async {
    expenses.add(e);
    expenses.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
    await _storage.saveExpenses(expenses);
  }

  Future<void> deleteExpense(String id) async {
    expenses.removeWhere((e) => e.id == id);
    notifyListeners();
    await _storage.saveExpenses(expenses);
  }

  Future<void> setBudget(double value) async {
    budget = value;
    notifyListeners();
    await _storage.saveBudget(value);
  }
}
