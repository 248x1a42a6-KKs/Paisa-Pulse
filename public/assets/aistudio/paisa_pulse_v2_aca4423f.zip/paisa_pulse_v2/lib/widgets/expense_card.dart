import 'package:flutter/material.dart';

import '../models/expense.dart';

class ExpenseCard extends StatelessWidget {
  final Expense expense;
  final VoidCallback onTap;

  const ExpenseCard({super.key, required this.expense, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 4,
      ),
      child: ListTile(
        leading: CircleAvatar(
          child: Icon(Icons.receipt),
        ),
        title: Text(
          expense.note,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text('${expense.category} • ${expense.dateText}'),
        trailing: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 100),
          child: Text(
            '₹${expense.amount.toStringAsFixed(2)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}
