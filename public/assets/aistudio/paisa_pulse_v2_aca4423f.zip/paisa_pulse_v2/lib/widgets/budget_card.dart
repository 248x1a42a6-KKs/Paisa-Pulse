import 'package:flutter/material.dart';

class BudgetCard extends StatelessWidget {
  final double spent;
  final double budget;
  final VoidCallback onTap;

  const BudgetCard({
    super.key,
    required this.spent,
    required this.budget,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    ColorScheme colors = Theme.of(context).colorScheme;

    if (budget == 0) {
      return Card(
        margin: EdgeInsets.symmetric(horizontal: 12),
        child: ListTile(
          leading: Icon(Icons.savings),
          title: Text('Set monthly budget'),
          subtitle: Text('Tap to set your budget'),
          onTap: onTap,
        ),
      );
    }

    double ratio = spent / budget;
    Color barColor = colors.primary;
    String message = '₹${(budget - spent).toStringAsFixed(0)} remaining';

    if (ratio > 1) {
      barColor = colors.error;
      message = 'Over budget by ₹${(spent - budget).toStringAsFixed(0)}';
    } else if (ratio >= 0.8) {
      barColor = colors.tertiary;
      message = 'Careful! ${(ratio * 100).round()}% of budget used';
    }

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 12),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Budget: ₹${budget.toStringAsFixed(0)}'),
              SizedBox(height: 8),
              LinearProgressIndicator(
                value: ratio > 1 ? 1 : ratio,
                color: barColor,
              ),
              SizedBox(height: 8),
              Text(message, style: TextStyle(color: barColor)),
            ],
          ),
        ),
      ),
    );
  }
}
