import 'package:flutter/material.dart';

class BudgetDialog extends StatefulWidget {
  final double current;

  const BudgetDialog({super.key, required this.current});

  @override
  State<BudgetDialog> createState() => _BudgetDialogState();
}

class _BudgetDialogState extends State<BudgetDialog> {
  late TextEditingController c = TextEditingController(
    text: widget.current > 0 ? widget.current.toStringAsFixed(0) : '',
  );
  String? errorText;

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  void save() {
    double? value = double.tryParse(c.text.trim());

    if (value == null) {
      setState(() => errorText = 'Enter a number');
    } else if (value <= 0) {
      setState(() => errorText = 'Must be more than 0');
    } else if (value > 10000000) {
      setState(() => errorText = 'That is too large');
    } else {
      Navigator.pop(context, value);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Monthly Budget'),
      content: TextField(
        controller: c,
        autofocus: true,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: 'Enter amount',
          prefixText: '₹ ',
          errorText: errorText,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
        FilledButton(
          onPressed: save,
          child: Text('Save'),
        ),
      ],
    );
  }
}
