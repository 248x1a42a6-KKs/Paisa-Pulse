import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:paisa_pulse/main.dart';
import 'package:paisa_pulse/services/expense_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('shows empty message and rejects an empty form', (tester) async {
    SharedPreferences.setMockInitialValues({});

    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => ExpenseProvider()..loadData(),
        child: MyApp(),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('No expenses yet'), findsOneWidget);

    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Save Expense'));
    await tester.pumpAndSettle();

    expect(find.text('Enter a number'), findsOneWidget);
    expect(find.text('Choose a category'), findsOneWidget);
    expect(find.text('Write at least 3 letters'), findsOneWidget);
  });
}
