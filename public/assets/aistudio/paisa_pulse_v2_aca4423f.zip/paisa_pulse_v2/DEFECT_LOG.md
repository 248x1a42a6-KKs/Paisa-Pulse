# Defect log

| # | Defect | Steps to reproduce | Fixed? |
|---|---|---|---|
| 1 | | | |

Test: empty input, very long text, no internet, repeated fast taps, phone sideways.
